package com.example.eecs4764s_to_t;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    ImageView mic;
    TextView Text;
    private static final int SPEECH_INPUT = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy tp = StrictMode.ThreadPolicy.LAX;
        StrictMode.setThreadPolicy(tp);
        mic = findViewById(R.id.mic);
        Text = findViewById(R.id.text);
        mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speech to Text");

                try {
                    startActivityForResult(intent, SPEECH_INPUT);
                }
                catch (Exception e){
                    Toast.makeText(MainActivity.this, " "+ e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode== SPEECH_INPUT){
            if (resultCode== RESULT_OK && data != null){
                ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String response = sendMessage(Objects.requireNonNull(result).get(0));
                Log.e("1", response);
                Text.setText(response);
            }
        }
    }



    public String sendMessage (String message) {
        String msg = "";
            try  {
                URL url = new URL(" http://58e7-129-236-224-68.ngrok.io");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                String cmd = message.toLowerCase();

                if (cmd.contains("on")){
                    conn.setRequestProperty("Display", "on");
                }
                else if (cmd.contains("off")){
                    conn.setRequestProperty("Display", "off");
                }
                else if (cmd.contains("time")){
                    conn.setRequestProperty("Display", "time");
                }
                else{
                    conn.setRequestProperty("Spoken_message", cmd);
                }

                OutputStream os = new BufferedOutputStream(conn.getOutputStream());

                os.flush();
                os.close();

                InputStream is = new BufferedInputStream(conn.getInputStream());
                BufferedReader bf = new BufferedReader(new InputStreamReader(
                        is, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();
                String line = "";
                while ((line = bf.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();

                msg = "";

                String res = sb.toString();

                Log.d("Your Data", res);
                int display_status = res.indexOf("Display");
                if (display_status != -1 && res.contains("on")) {
                    msg = "";
                    msg += "Display turned on";
                }
                else if (display_status != -1 && res.contains("off")){
                        msg = "";
                        msg += "Display turned off";
                }

                int time_status = res.indexOf("Time");
                if (time_status != -1){
                        msg = "";
                        msg += "Time displayed";
                }
                int spoken_status = res.indexOf("Spoken");
                if (spoken_status != -1){
                    msg = "";
                    msg += "Spoken message displayed";
                }
                return msg;
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        return "Error";
    }
}